package id.paradox.zx68.usb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import id.paradox.zx68.protocol.DeviceIds
import id.paradox.zx68.protocol.M3Frame
import id.paradox.zx68.util.Hex
import id.paradox.zx68.util.LogBus

/**
 * Transport HID di atas Android USB Host API (tanpa root).
 *
 * ## Kenapa bukan hidapi
 * Driver Windows HIDComm.dll membuka perangkat lewat CreateFileW lalu
 * mengirim data dengan WriteFile (lihat akses write di CreateFileW di
 * RVA 0x1370).
 *
 * Dalam Android:
 * 1. UsbManager.openDevice() → UsbDeviceConnection
 * 2. claimInterface(iface, force=true) → lepaskan driver kernel untuk
 *    perangkat seperti CreateFileW di Windows.
 * 3. bulkTransfer(outEndpoint, data, len, timeoutMs) untuk mengirim 64 byte.
 * 4. bulkTransfer(inEndpoint, buffer, len, timeoutMs) untuk membaca reply.
 *
 * ## Izin
 * Android mewajibkan izin runtime per perangkat. requestPermission memakai
 * PendingIntent + broadcast ACTION_USB_PERMISSION.
 */
class UsbHidTransport(private val context: Context) {

    private val usbManager: UsbManager =
        context.getSystemService(Context.USB_SERVICE) as UsbManager

    private var connection: UsbDeviceConnection? = null
    private var usbInterface: UsbInterface? = null
    private var outEndpoint: UsbEndpoint? = null
    private var inEndpoint: UsbEndpoint? = null

    /** Perangkat yang sedang dibuka, atau null. */
    var device: UsbDevice? = null
        private set

    /** true bila koneksi aktif dan antarmuka sudah di-claim. */
    val isOpen: Boolean get() = connection != null

    companion object {
        const val ACTION_USB_PERMISSION = "id.paradox.zx68.USB_PERMISSION"

        const val TIMEOUT_MS = 5000
    }

    // -------------------------------------------------------------------
    // Pencarian perangkat
    // -------------------------------------------------------------------

    /** Semua perangkat USB yang terpasang saat ini. */
    fun listDevices(): List<UsbDevice> =
        usbManager.deviceList.values.toList()

    /**
     * Mencari keyboard ZX68 yang terpasang.
     */
    fun findDevice(allowFamily: Boolean = false): UsbDevice? =
        listDevices().firstOrNull {
            if (allowFamily) {
                DeviceIds.isSameFamily(it.vendorId, it.productId)
            } else {
                DeviceIds.isZx68(it.vendorId, it.productId)
            }
        }

    fun hasPermission(device: UsbDevice): Boolean =
        usbManager.hasPermission(device)

    /** Jumlah perangkat yang terdeteksi untuk log. */
    fun deviceCount(): Int = listDevices().size

    /**
     * Deskripsi ringkas device untuk log debug.
     */
    fun describe(device: UsbDevice): String {
        val sb = StringBuilder()
        sb.append(device.deviceName ?: "USB device")
        sb.append(" VID=0x${device.vendorId.toInt()}")
        sb.append(" PID=0x${device.productId.toInt()}")
        device.productName?.let { sb.append(" name=$it") }
        return sb.toString()
    }

    /**
     * Meminta izin pemakaian perangkat secara asinkron.
     */
    fun requestPermission(
        device: UsbDevice,
        callback: (granted: Boolean) -> Unit,
    ) {
        if (usbManager.hasPermission(device)) {
            callback(true)
            return
        }

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action != ACTION_USB_PERMISSION) return
                val granted = intent.getBooleanExtra(
                    UsbManager.EXTRA_PERMISSION_GRANTED, false)
                try { context.unregisterReceiver(this) } catch (_: Throwable) {}
                LogBus.log(
                    if (granted) "Izin USB diberikan" else "Izin USB ditolak")
                callback(granted)
            }
        }

        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(ACTION_USB_PERMISSION),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )

        val pendingFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_UPDATE_CURRENT
        } else {
            0
        }

        val intent = Intent(ACTION_USB_PERMISSION)
            .setPackage(context.packageName)

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            intent,
            pendingFlags,
        )

        usbManager.requestPermission(device, pendingIntent)
    }

    // -------------------------------------------------------------------
    // Buka / tutup
    // -------------------------------------------------------------------

    /**
     * Membuka perangkat, memilih antarmuka yang punya endpoint OUT, lalu
     * meng-claim-nya.
     *
     * Keyboard gaming biasanya mengekspos lebih dari satu HID interface:
     * interface 0 adalah keyboard boot (hanya IN), sedangkan interface vendor
     * (1 atau 2) memegang endpoint OUT 64 byte untuk protokol konfigurasi.
     *
     * @return true bila siap mengirim/menerima paket.
     */
    fun open(device: UsbDevice): Boolean {
        close()

        val conn = usbManager.openDevice(device) ?: run {
            LogBus.log("Gagal openDevice (izin belum diberikan?)")
            return false
        }

        val candidates = candidateInterfaces(device)
        if (candidates.isEmpty()) {
            LogBus.log("Perangkat tidak mengekspos antarmuka apa pun")
            conn.close()
            return false
        }

        LogBus.log("Kandidat antarmuka: " + candidates.size)

        var fallback: Pair<UsbInterface, UsbEndpoint?>? = null

        for (iface in candidates) {
            val claimed = conn.claimInterface(iface, true)
            LogBus.log(
                "claimInterface(#${iface.id}, force=true) = $claimed " +
                    "(${iface.interfaceClass}/${iface.interfaceSubclass}/${iface.interfaceProtocol})")

            if (!claimed) continue

            val epOut = findEndpoint(iface, UsbConstants.USB_DIR_OUT)
            val epIn = findEndpoint(iface, UsbConstants.USB_DIR_IN)

            if (epOut != null) {
                adopt(conn, iface, epOut, epIn, device)
                return true
            }

            if (fallback == null) fallback = iface to epIn
            runCatching { conn.releaseInterface(iface) }
        }

        val spare = fallback
        if (spare != null && conn.claimInterface(spare.first, true)) {
            adopt(conn, spare.first, null, spare.second, device)
            LogBus.log("Tidak ada endpoint OUT; memakai SET_REPORT lewat control transfer")
            return true
        }

        conn.close()
        LogBus.log("Gagal meng-claim antarmuka USB yang bisa dipakai")
        return false
    }

    private fun adopt(
        conn: UsbDeviceConnection,
        iface: UsbInterface,
        epOut: UsbEndpoint?,
        epIn: UsbEndpoint?,
        device: UsbDevice,
    ) {
        epOut?.let { warnPacketSize(it) }
        connection = conn
        usbInterface = iface
        outEndpoint = epOut
        inEndpoint = epIn
        this.device = device
    }

    fun close() {
        connection?.let { conn ->
            usbInterface?.let { iface ->
                runCatching { conn.releaseInterface(iface) }
                runCatching { conn.setInterface(iface) }
            }
            runCatching { conn.close() }
        }
        connection = null
        usbInterface = null
        outEndpoint = null
        inEndpoint = null
        device = null
    }

    // -------------------------------------------------------------------
    // Kirim / terima
    // -------------------------------------------------------------------

    /** Mengirim satu paket 64 byte. */
    fun send(data: ByteArray, timeoutMs: Int = TIMEOUT_MS): Int {
        val conn = connection ?: return -1
        val out = outEndpoint

        val sent = if (out != null) {
            conn.bulkTransfer(out, data, data.size, timeoutMs)
        } else {
            val iface = usbInterface ?: return -1
            conn.controlTransfer(
                0x21,
                0x09,
                0x0200,
                iface.id,
                data,
                data.size,
                timeoutMs,
            )
        }
        return if (sent < 0) -1 else sent
    }

    /** Membaca balasan perangkat (maksimal M3Frame.PACKET_SIZE byte). */
    fun receive(timeoutMs: Int = TIMEOUT_MS): ByteArray? {
        val conn = connection ?: return null
        val buffer = ByteArray(M3Frame.PACKET_SIZE)
        val inEp = inEndpoint

        val read = if (inEp != null) {
            conn.bulkTransfer(inEp, buffer, buffer.size, timeoutMs)
        } else {
            val iface = usbInterface ?: return null
            conn.controlTransfer(
                0xA1,
                0x01,
                0x0100,
                iface.id,
                buffer,
                buffer.size,
                timeoutMs,
            )
        }
        return if (read > 0) buffer.copyOf(read) else null
    }

    /** Hasil satu transaksi. */
    data class Transfer(
        val sentBytes: Int,
        val response: ByteArray?,
    ) {
        val sentOk: Boolean get() = sentBytes > 0
    }

    /** Mengirim paket, lalu (opsional) membaca balasan. */
    fun transact(
        request: ByteArray,
        readTimeoutMs: Int = 400,
        expectReply: Boolean = true,
    ): Transfer {
        LogBus.log("TX ${Hex.format(request)}")
        val sent = send(request)
        if (sent < 0) {
            LogBus.log("TX gagal (bulkTransfer/controlTransfer = $sent)")
            return Transfer(sent, null)
        }
        if (!expectReply) return Transfer(sent, null)

        val response = receive(readTimeoutMs)
        if (response != null) {
            LogBus.log("RX ${Hex.format(response)}")
        } else {
            LogBus.log("RX (tidak ada balasan)")
        }
        return Transfer(sent, response)
    }

    // -------------------------------------------------------------------
    // Helper internal
    // -------------------------------------------------------------------

    private fun candidateInterfaces(device: UsbDevice): List<UsbInterface> =
        (0 until device.interfaceCount)
            .map { device.getInterface(it) }
            .sortedByDescending { scoreInterface(it) }

    private fun scoreInterface(iface: UsbInterface): Int {
        var score = if (iface.interfaceClass == UsbConstants.USB_CLASS_HID) 5 else 0
        for (i in 0 until iface.endpointCount) {
            val ep = iface.getEndpoint(i)
            if (ep.direction != UsbConstants.USB_DIR_OUT) continue
            score += when (ep.type) {
                UsbConstants.USB_ENDPOINT_XFER_INT -> 100
                UsbConstants.USB_ENDPOINT_XFER_BULK -> 60
                else -> 10
            }
            if (ep.maxPacketSize >= M3Frame.PACKET_SIZE) score += 20
        }
        return score
    }

    private fun warnPacketSize(epOut: UsbEndpoint) {
        if (epOut.maxPacketSize < M3Frame.PACKET_SIZE) {
            LogBus.log(
                "Peringatan: maxPacketSize=${epOut.maxPacketSize} < 64; " +
                    "paket bisa terpotong oleh firmware",
            )
        }
    }

    private fun findEndpoint(iface: UsbInterface, direction: Int): UsbEndpoint? {
        var bulkFallback: UsbEndpoint? = null
        for (i in 0 until iface.endpointCount) {
            val ep = iface.getEndpoint(i)
            if (ep.direction != direction) continue
            when (ep.type) {
                UsbConstants.USB_ENDPOINT_XFER_INT -> return ep
                UsbConstants.USB_ENDPOINT_XFER_BULK -> bulkFallback = ep
            }
        }
        return bulkFallback
    }

    private fun describeEndpoint(ep: UsbEndpoint): String =
        "addr=0x%02X type=%d maxPacket=%d".format(ep.address, ep.type, ep.maxPacketSize)
}

fun __NOT_USED__(): Unit = TODO("remove after staging")
